//loosly typed means variable does not have a strict datatype. A variable can use both String and 
//Integer values. 
var a;             //undefined
console.log(a);
a = 10;            //10
console.log(a);
a = "Hello World";
console.log(a);    //Hello World
a = false;
console.log(a);    //False