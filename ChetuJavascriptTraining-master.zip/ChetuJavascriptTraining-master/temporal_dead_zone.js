// console.log(x); // x here is in Temporal Dead Zone throws Reference error
// console.log(y);  // y is also in Temporal Dead Zone and it is undefined over here
// console.log(z);  // x here is in Temporal Dead Zone throws Reference error
// console.log(a); // New type of Reference error : a is not defined
let x = 10;

var y = 20;

const z = 20;

// let x = 200; // Redeclaration of x : Gives SyntaxError (x is already declared)

var y = 400 // Redeclaration of var y is allowed and no error is thrown

// const b; //Gives SyntaxError : missing initializer (even more strict that let)

const c = 100;

// c=20;  //TypeError: Assignment to constant variable

const arr = [20,30]

arr.length=90**99 //Throws RangeError: (invalid array length)
//Next, we try to grow the array to contain 90**99 == 2.9512665430652753e+193 elements