console.log(a);//a is assigned memory even before a is defined (a is undefined)

var a = 7;

console.log(x)//(x is not defined and has not allocated any memory) 