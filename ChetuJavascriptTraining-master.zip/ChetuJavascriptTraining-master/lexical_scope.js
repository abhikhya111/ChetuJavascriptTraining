function function1(a)
{
    var b = a * 2;
    function function2(c)
    {
        console.log(a+' '+ b+' '+c)
    }
    function2(b*3)

}

function1(2)